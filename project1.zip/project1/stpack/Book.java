package stpack;

public class Book {
	private String name;

private String Author;

private int ISBNno;

private int rackno;

private boolean bookstatus;


private void Bookdetails() {
}

public void Updatestatus() {
}

}


