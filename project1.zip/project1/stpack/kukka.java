package stpack;

public class kukka extends Book{

}
