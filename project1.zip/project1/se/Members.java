package se;

import java.util.Vector;

public class Members {

  private int Id;

  public String name;

  public int phone;

  public String address;

  public int BookIssue;

  public int duration;

    public Vector  myMembers_Record;

  public void Issue() {
  }

  public void deletebook() {
  }

}