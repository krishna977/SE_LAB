package se;

public class PGstudents extends Members {
}