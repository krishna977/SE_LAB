package se;

public class Faculty extends Members {
}