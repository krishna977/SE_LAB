package se;

public class ResearchScholars extends Members {
}