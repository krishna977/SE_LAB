package se;

import java.util.Vector;

public class Members_Record {

  private int memberId;

  private String type;

    public Vector  register;
    public Vector  myMembers1;
    public Vector  myMembers;
    public Vector  myLibrarian;
    public Vector  pays;
    public Vector  sends_msg;

  public void retrieveMember() {
  }

}