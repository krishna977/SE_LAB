package se;

import java.util.Vector;

public class Penalty {

  private int billno;

  private int date;

  private int memberId;

  private int amount;

    public Vector  pays;
    public Vector  refers;

  public void billCreate() {
  }

  public void billUpdate() {
  }

}