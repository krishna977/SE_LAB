package se;

import java.util.Vector;

public class Book {

  private String name;

  private String Author;

  private int ISBNno;

  private int rackno;

  private boolean bookstatus;

  public int reserveno;

    public Vector  register;
    public Vector  issues;

  private void Bookdetails() {
  }

  public void Updatestatus() {
  }

}